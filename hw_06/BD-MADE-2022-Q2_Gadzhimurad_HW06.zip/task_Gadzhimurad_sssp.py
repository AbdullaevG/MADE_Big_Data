from pyspark.sql import SparkSession
from pyspark.sql.functions import col

end_user = 34
start_user = 12
dist = 0


spark = SparkSession.builder.appName("classifier").getOrCreate()

df = (
    spark
    .read
    .format("csv")
    .options(header=False, inferSchema=True, sep="\t")
    .load("hdfs:///data/twitter/twitter.txt")
)

df = df.select(col("_c0").alias("user1"), col("_c1").alias("user2"))

used_users = {start_user}
temp_users = {start_user}

while len(temp_users) > 0:
    temp_users = (
        df
        .filter(col("user2").isin(temp_users))
        .select(col("user1"))
        .dropDuplicates()
        .collect()
    )
    dist += 1
    temp_users = {item["user1"] for item in temp_users}
    if end_user in temp_users:
        break
    temp_users -= used_users
    used_users |= temp_users

print(dist)

